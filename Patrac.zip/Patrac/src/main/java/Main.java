/**
 * Created by jencek on 27.2.17.
 */
public class Main {
    public static void main(String[] args) {
        Radial.printSectors();
    }
}
