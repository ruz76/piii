package cz.vsb.ruz76.piii;

import java.util.ArrayList;

/**
 * Created by ruz76 on 29.3.2017.
 */
public class Measures extends ArrayList {

}
